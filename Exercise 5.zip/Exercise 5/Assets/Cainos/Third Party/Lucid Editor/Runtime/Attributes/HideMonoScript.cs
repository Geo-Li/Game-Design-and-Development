using System;
using UnityEngine;

namespace Cainos.LucidEditor
{
    [AttributeUsage(AttributeTargets.Class)]
    public class HideMonoScriptAttribute : Attribute { }
}